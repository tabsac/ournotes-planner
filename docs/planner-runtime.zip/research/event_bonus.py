"""Reproducible event bonuses from the pinned, local bdon research snapshot.

This calculates selected cards' bonuses, not a legal deck, team power, a score,
or rewards. Only the inventory fields needed here are required. Exact percent
values are decimal strings; the authoritative values are integers with
10000 = 100%. No rounding is applied before currency bonuses are added.
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path


TABLE_NAMES = (
    "MasterEvent", "MasterEventEffect", "MasterMemberCard",
    "MasterSupportCard", "MasterCharacter", "MasterMemberCardRank",
    "MasterSupportCardRank",
)
BONUS_NAMES = {0: "event_pt", 1: "shop_pt", 2: "parameter"}


def _integer(value: object, label: str, minimum: int = 0, maximum: int | None = None) -> int:
    if type(value) is not int:
        raise ValueError(f"{label} must be an integer; booleans are not accepted")
    if value < minimum or (maximum is not None and value > maximum):
        raise ValueError(f"{label} is outside the supported range")
    return value


def _read_json(path: Path) -> object:
    return json.loads(path.read_text(encoding="utf-8"))


def _load_table(snapshot_dir: Path, name: str, file_manifest: dict) -> list[dict]:
    relative = f"raw/{name}.json"
    entry = file_manifest.get(relative)
    if entry is None:
        raise ValueError(f"Snapshot manifest does not contain {relative}")
    payload = (snapshot_dir / relative).read_bytes()
    if hashlib.sha256(payload).hexdigest() != entry["sha256"]:
        raise ValueError(f"Snapshot checksum does not match: {relative}")
    table = json.loads(payload)
    if not isinstance(table, dict) or not isinstance(table.get("_allData"), list):
        raise ValueError(f"Invalid table shape: {relative}")
    rows = table["_allData"]
    _index(rows, name)
    return rows


def _index(rows: list[dict], label: str) -> dict[int, dict]:
    indexed = {}
    for row in rows:
        if not isinstance(row, dict):
            raise ValueError(f"{label} must contain objects")
        identifier = _integer(row.get("_id"), f"{label}._id", minimum=1)
        if identifier in indexed:
            raise ValueError(f"Duplicate ID {identifier} in {label}")
        indexed[identifier] = row
    return indexed


def _inventory(profile: dict, kind: str) -> dict[int, dict]:
    inventory = profile.get("inventory")
    if not isinstance(inventory, dict) or not isinstance(inventory.get(kind), list):
        raise ValueError(f"profile.inventory.{kind} must be an array")
    indexed = {}
    for entry in inventory[kind]:
        if not isinstance(entry, dict):
            raise ValueError(f"profile.inventory.{kind} entries must be objects")
        identifier = _integer(entry.get("id"), f"inventory.{kind}.id", minimum=1)
        if identifier in indexed:
            raise ValueError(f"Duplicate inventory {kind} ID {identifier}")
        indexed[identifier] = entry
    return indexed


def _selected(ids: list[int], inventory: dict[int, dict], kind: str) -> list[int]:
    if not isinstance(ids, list):
        raise ValueError(f"Selected {kind} IDs must be an explicit array")
    seen = set()
    for identifier in ids:
        _integer(identifier, f"selected {kind} ID", minimum=1)
        if identifier in seen:
            raise ValueError(f"Duplicate selected {kind} ID {identifier}")
        if identifier not in inventory:
            raise ValueError(f"Selected {kind} ID {identifier} is not owned")
        seen.add(identifier)
    return ids


def _rank(card: dict, owned: dict, count_key: str, group_key: str,
          rank_rows: list[dict], label: str) -> int:
    if count_key not in owned:
        raise ValueError(f"{label} requires its actual {count_key}; no default is assumed")
    count = _integer(owned[count_key], f"{label}.{count_key}", maximum=4)
    raw_rank = count + 1
    group = _integer(card.get(group_key), f"{label}.{group_key}", minimum=1)
    matches = [row for row in rank_rows if row["_group"] == group and row["_rank"] == raw_rank]
    if len(matches) != 1:
        raise ValueError(f"{label}: expected one rank {raw_rank} row in group {group}")
    return raw_rank


def _matches_member(effect: dict, card: dict, character: dict) -> bool:
    if effect["_resourceTypeConstraint"] != 2:
        return False
    keys = (
        ("_characterId", card["_characterID"]),
        ("_bandId", character["_bandID"]),
        ("_cardType", card["_cardType"]),
        ("_memberCardId", card["_id"]),
    )
    if any(effect[key] != 0 and effect[key] != value for key, value in keys):
        return False
    return effect["_tagId"] == 0 or effect["_tagId"] in card["_bestMusicTagIDs"]


def _matches_snap(effect: dict, card: dict, characters: dict[int, dict]) -> bool:
    if effect["_resourceTypeConstraint"] != 3 or effect["_tagId"] != 0:
        return False
    character_ids = card["_characterIDs"]
    band_ids = {characters[identifier]["_bandID"] for identifier in character_ids}
    if effect["_characterId"] != 0 and effect["_characterId"] not in character_ids:
        return False
    if effect["_bandId"] != 0 and effect["_bandId"] not in band_ids:
        return False
    return all(effect[key] == 0 or effect[key] == value for key, value in (
        ("_cardType", card["_cardType"]), ("_supportCardId", card["_id"]),
    ))


def _exact_percent(value: int) -> str:
    integer_part, fraction = divmod(value, 100)
    if not fraction:
        return str(integer_part)
    return f"{integer_part}.{fraction:02d}".rstrip("0")


def _bonus_summary(values: dict[str, int]) -> dict:
    result = {}
    for name, value in values.items():
        result[f"{name}_bonus_10000"] = value
        result[f"{name}_bonus_percent_exact"] = _exact_percent(value)
        result[f"{name}_bonus_percent_display"] = value // 100
    return result


def _card_result(kind: str, card: dict, rank: int, matching: list[dict]) -> dict:
    values = {name: 0 for name in BONUS_NAMES.values()}
    matched = []
    for effect in matching:
        bonus_type = effect["_eventBonusType"]
        value = _integer(effect.get(f"_rank{rank}EffectValue"),
                         f"effect {effect['_id']} rank {rank} value")
        values[BONUS_NAMES[bonus_type]] += value
        matched.append({"effect_id": effect["_id"], "bonus_type": bonus_type,
                        "bonus_10000": value})
    return {
        "kind": kind, "id": card["_id"], "count": rank - 1, "raw_rank": rank,
        **_bonus_summary(values),
        "matched_effect_row_ids": [entry["effect_id"] for entry in matched],
        "matched_effects": matched,
    }


def _sum_currency_bonuses(cards: list[dict]) -> dict:
    """Add the exact integers; card display percentages are never inputs."""
    return _bonus_summary({name: sum(card[f"{name}_bonus_10000"] for card in cards)
                           for name in ("event_pt", "shop_pt")})


def calculate_deck_bonuses(snapshot_dir: Path, profile: dict,
                           member_ids: list[int], snap_ids: list[int],
                           event_id: int = 1) -> dict:
    """Calculate explicitly selected cards with actual awakening/break counts.

    This consumes the profile's inventory subset, not the full profile schema.
    An empty selection is allowed and returns zero. Inventory is never assumed
    to be a deck. Unselected cards need no development fields for this function.
    Any complete deck legality check must be performed separately.
    """
    event_id = _integer(event_id, "event_id", minimum=1)
    if not isinstance(profile, dict):
        raise ValueError("profile must be an object")
    member_inventory = _inventory(profile, "members")
    snap_inventory = _inventory(profile, "snaps")
    member_ids = _selected(member_ids, member_inventory, "members")
    snap_ids = _selected(snap_ids, snap_inventory, "snaps")
    snapshot_dir = Path(snapshot_dir)
    manifest = _read_json(snapshot_dir / "source_manifest.json")
    file_manifest = {entry["local_path"]: entry for entry in manifest["files"]}
    tables = {name: _load_table(snapshot_dir, name, file_manifest) for name in TABLE_NAMES}
    if event_id not in _index(tables["MasterEvent"], "MasterEvent"):
        raise ValueError(f"Unknown event ID {event_id} in this snapshot")
    effects = [row for row in tables["MasterEventEffect"] if row["_eventId"] == event_id]
    for effect in effects:
        bonus_type = _integer(effect.get("_eventBonusType"), "event bonus type")
        if bonus_type not in BONUS_NAMES:
            raise ValueError(f"Unsupported event bonus type {bonus_type}")
    member_cards = _index(tables["MasterMemberCard"], "MasterMemberCard")
    snap_cards = _index(tables["MasterSupportCard"], "MasterSupportCard")
    characters = _index(tables["MasterCharacter"], "MasterCharacter")
    selected_members = []
    selected_snaps = []
    for identifier in member_ids:
        if identifier not in member_cards:
            raise ValueError(f"Unknown member ID {identifier} in this snapshot")
        card = member_cards[identifier]
        character = characters.get(card["_characterID"])
        if character is None:
            raise ValueError(f"Member {identifier} has no character row")
        rank = _rank(card, member_inventory[identifier], "awakening_count",
                     "_memberCardRankGroup", tables["MasterMemberCardRank"],
                     f"member {identifier}")
        matching = [row for row in effects if _matches_member(row, card, character)]
        selected_members.append(_card_result("member", card, rank, matching))
    for identifier in snap_ids:
        if identifier not in snap_cards:
            raise ValueError(f"Unknown Snap ID {identifier} in this snapshot")
        card = snap_cards[identifier]
        if any(char_id not in characters for char_id in card["_characterIDs"]):
            raise ValueError(f"Snap {identifier} has a missing character row")
        rank = _rank(card, snap_inventory[identifier], "limit_break_count",
                     "_supportCardRankGroup", tables["MasterSupportCardRank"],
                     f"Snap {identifier}")
        matching = [row for row in effects if _matches_snap(row, card, characters)]
        selected_snaps.append(_card_result("snap", card, rank, matching))
    return {
        "event_id": event_id,
        "selected_member_ids": list(member_ids), "selected_snap_ids": list(snap_ids),
        "total": _sum_currency_bonuses(selected_members + selected_snaps),
        "members": selected_members, "snaps": selected_snaps,
        "source": {
            "primary_provider": manifest["primary_provider"],
            "data_repository": manifest["data_repository"],
            "data_commit": manifest["data_commit"],
            "snapshot_label": manifest["source_snapshot"],
            "snapshot_version": manifest["snapshot_version"]["version"],
            "model_repository": manifest["bdon_linked_model_repository"],
            "model_commit": manifest["bdon_linked_model_commit"],
            "table_sha256": {name: file_manifest[f"raw/{name}.json"]["sha256"]
                             for name in TABLE_NAMES},
        },
        "validation_scope": {
            "current_event_game_ui_supported": event_id == 1,
            "game_ui_evidence": "Six supplied event-1 rule screenshots support bonus roles, curves and additive matching conditions.",
            "currency_aggregation": "Sum across selected cards follows the bdon-linked reference model. The supplied known real deck for event 1 matches both its +108% event PT and +140% shop PT game displays.",
            "known_real_deck_evidence": "validation/party_sample_calibration.json",
            "known_challenge_receipt_evidence": "validation/challenge_receipt_IMG_0526_0527.json",
            "parameter_scope": "Per-card only; no aggregate team-power percentage is calculated.",
            "inventory_scope": "Only required bonus fields are checked; this is not full profile-schema validation.",
            "not_validated": ["complete deck legality", "team power", "score", "reward amount", "other event game UI"],
        },
    }
