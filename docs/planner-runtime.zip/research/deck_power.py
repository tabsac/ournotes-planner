"""Research deck power for a complete five-slot ordinary or challenge selection.

This is the pinned bdon-linked model's power arithmetic, independently calibrated
against one supplied in-game team. It is not a score simulator. Actual growth,
applicable facilities, each selected character's rank, total rank, and T.G.W
rank are mandatory. Unsupported leader conditions and nonempty memory tables
raise errors instead of being replaced by guessed bonuses.
"""

from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path

try:
    from . import card_power, event_bonus
except ImportError:
    import card_power
    import event_bonus


PARAMETERS = card_power.PARAMETERS
DECK_TABLE_NAMES = (
    "MasterCharacterRank", "MasterCharacterTotalRank", "MasterVipRankBonus",
    "MasterParameter", "MasterBandItem", "MasterBandItemLevel",
    "MasterBandItemSkillEffect", "MasterSkillTarget", "MasterLiveMusic",
    "MasterChallengeMusic", "MasterLeaderSkill", "MasterLeaderSkillEffect",
    "MasterBand", "MasterMemoryMemberLevel", "MasterMemorySupportLevel",
    "MasterMemoryMusicBonus",
)
MODEL_SOURCES = tuple(f"model_reference/src/{name}.rs" for name in (
    "calc", "bonus", "power", "num", "cards", "deck", "master", "event",
))
REQUIRED_PATHS = tuple(dict.fromkeys(
    card_power.REQUIRED_PATHS + tuple(f"raw/{name}.json" for name in event_bonus.TABLE_NAMES)
    + tuple(f"raw/{name}.json" for name in DECK_TABLE_NAMES) + MODEL_SOURCES
))
COMPONENT_NAMES = (
    "members", "snaps", "leader_skill", "band_items", "character_rank",
    "type_link", "type_bonus", "favored_music", "tgw_card",
)
ZERO = (0, 0, 0)
UNIT = 10000


def _integer(value: object, label: str, minimum: int = 0, maximum: int | None = None) -> int:
    return card_power._integer(value, label, minimum, maximum)


def _required(entry: dict, key: str, label: str, minimum: int = 0) -> int:
    return card_power._required_integer(entry, key, label, minimum)


def _wrap64(value: int) -> int:
    return (value + 2 ** 63) % (2 ** 64) - 2 ** 63


def _wrap32(value: int) -> int:
    return (value + 2 ** 31) % (2 ** 32) - 2 ** 31


def _trunc_div(value: int, divisor: int) -> int:
    return value // divisor if value >= 0 else -((-value) // divisor)


def _floor_i32(value: float) -> int:
    if math.isnan(value):
        return 0
    if math.isinf(value):
        return -(2 ** 31)
    return max(-(2 ** 31), min(2 ** 31 - 1, math.floor(value)))


def _add(*vectors: tuple[int, int, int]) -> tuple[int, int, int]:
    return tuple(_wrap64(sum(vector[index] for vector in vectors)) for index in range(3))


def _to_floor_bp(vector: tuple[int, int, int]) -> tuple[int, int, int]:
    return tuple(_wrap64(_floor_i32(card_power._float32(card_power._float32(value) / UNIT)) * UNIT)
                 for value in vector)


def _mul_floor(power_bp: tuple[int, int, int], rates: tuple[int, int, int]) -> tuple[int, int, int]:
    products = tuple(_trunc_div(_wrap64(value * rate), UNIT) for value, rate in zip(power_bp, rates, strict=True))
    return _to_floor_bp(products)


def _bp(points: dict[str, int]) -> tuple[int, int, int]:
    return tuple(_wrap64(points[name] * UNIT) for name in PARAMETERS)


def _values(vector: tuple[int, int, int], *, points: bool = False) -> dict[str, int]:
    values = tuple(_floor_i32(value / UNIT) if points else value for value in vector)
    result = dict(zip(PARAMETERS, values, strict=True))
    if points:
        result["total"] = _wrap32(sum(values))
    return result


def _snapshot(snapshot_dir: Path) -> tuple[dict, dict[str, list[dict]]]:
    manifest = json.loads((snapshot_dir / "source_manifest.json").read_text(encoding="utf-8"))
    entries = {row["local_path"]: row for row in manifest["files"]}
    tables = {}
    for relative in REQUIRED_PATHS:
        if relative not in entries:
            raise ValueError(f"Snapshot manifest does not contain {relative}")
        payload = (snapshot_dir / relative).read_bytes()
        if hashlib.sha256(payload).hexdigest() != entries[relative]["sha256"]:
            raise ValueError(f"Snapshot checksum does not match: {relative}")
        if relative.startswith("raw/"):
            table = json.loads(payload)
            if not isinstance(table, dict) or not isinstance(table.get("_allData"), list):
                raise ValueError(f"Invalid table shape: {relative}")
            rows = table["_allData"]
            ids = set()
            for row in rows:
                if not isinstance(row, dict) or type(row.get("_id")) not in (str, int) or row["_id"] in ids:
                    raise ValueError(f"Invalid or duplicate table ID in {relative}")
                ids.add(row["_id"])
            tables[Path(relative).stem] = rows
    return manifest, tables


def _unique(rows: list[dict], label: str, **criteria: int) -> dict:
    return card_power._unique(rows, label, **criteria)


def _target_selectors(target: dict) -> None:
    unsupported = (
        target["_judgement"] != -1 or target["_liveMusicType"] != 0
        or target["_gekisouMissionType"] != 0 or target["_liveSkillCategories"]
        or target["_gekisouSkillCategories"]
    )
    if unsupported:
        raise ValueError(f"Unsupported conditional or skill-category target {target['_id']}")


def _target_matches(target: dict, card: dict, character: dict) -> bool:
    _target_selectors(target)
    return any((
        target["_bandID"] > 0 and target["_bandID"] == character["_bandID"],
        target["_characterID"] > 0 and target["_characterID"] == card["_characterID"],
        target["_cardType"] != 0 and target["_cardType"] == card["_cardType"],
        target["_tagID"] > 0 and target["_tagID"] in card["_bestMusicTagIDs"],
    ))


def _facility_matches(target: dict, card: dict, character: dict) -> int:
    _target_selectors(target)
    if target["_tagID"]:
        raise ValueError(f"Unsupported band-item tag target {target['_id']}")
    # The reference files an effect under every nonzero selector separately.
    return sum((
        target["_bandID"] > 0 and target["_bandID"] == character["_bandID"],
        target["_characterID"] > 0 and target["_characterID"] == card["_characterID"],
        target["_cardType"] != 0 and target["_cardType"] == card["_cardType"],
    ))


def _effect_rates(effect: dict) -> tuple[int, int, int]:
    effect_type = effect["_skillEffectType"]
    axes = {1000: (0, 1, 2), 1001: (1,), 1002: (2,), 1003: (0,)}
    if effect_type not in axes:
        raise ValueError(f"Unsupported power effect type {effect_type} in row {effect['_id']}")
    value = _integer(effect["_effectValue"], "effect value")
    return tuple(value if index in axes[effect_type] else 0 for index in range(3))


def _leader_rates(tables: dict, leader: dict, level: int, cards: list[dict],
                  characters: list[dict]) -> tuple[list[tuple[int, int, int]], list[list[int]]]:
    _unique(tables["MasterLeaderSkill"], "leader skill", _id=leader["_leaderSkillID"])
    effects = [row for row in tables["MasterLeaderSkillEffect"]
               if row["_leaderSkillID"] == leader["_leaderSkillID"] and row["_level"] == level]
    if not effects:
        raise ValueError("Leader has no effects at its derived skill level")
    rates = [ZERO for _ in cards]
    used = [[] for _ in cards]
    for effect in effects:
        if any(effect[key] != 0 for key in (
                "_skillConditionGroup", "_skillCumulativeConditionID", "_effectExecuteLimitCount",
                "_effectExecuteLimitResetConditionGroup")) or 1500 <= effect["_skillEffectType"] <= 1503:
            raise ValueError(f"Unsupported conditional or cumulative leader effect {effect['_id']}")
        effect_rate = _effect_rates(effect)
        targets = [_unique(tables["MasterSkillTarget"], "leader target", _id=identifier)
                   for identifier in effect["_skillTargetIDs"]]
        for index, (card, character) in enumerate(zip(cards, characters, strict=True)):
            if not targets or any(_target_matches(target, card, character) for target in targets):
                rates[index] = _add(rates[index], effect_rate)
                used[index].append(effect["_id"])
    return rates, used


def _indexed_player_rows(profile: dict, key: str, id_key: str) -> dict[int, dict]:
    rows = profile.get(key)
    if not isinstance(rows, list):
        raise ValueError(f"profile.{key} requires actual entries; no default is assumed")
    result = {}
    for row in rows:
        if not isinstance(row, dict):
            raise ValueError(f"profile.{key} entries must be objects")
        identifier = _required(row, id_key, key, minimum=1)
        if identifier in result:
            raise ValueError(f"Duplicate {key} ID {identifier}")
        result[identifier] = row
    return result


def _band_rates(tables: dict, profile: dict, cards: list[dict], characters: list[dict]) -> tuple[list, list]:
    facilities = _indexed_player_rows(profile, "facilities", "id")
    available = {row["_id"] for row in tables["MasterBandItem"]}
    for identifier, owned in facilities.items():
        if identifier not in available:
            raise ValueError(f"Unknown facility {identifier}")
        level = _required(owned, "level", f"facility {identifier}", minimum=0)
        if level:   # 0 = 未解锁，没有等级行可查
            _unique(tables["MasterBandItemLevel"], f"facility {identifier} level",
                    _bandItemId=identifier, _level=level)
    effect_targets = {}
    required_ids = set()
    for effect in tables["MasterBandItemSkillEffect"]:
        targets = [_unique(tables["MasterSkillTarget"], "facility target", _id=identifier)
                   for identifier in effect["_skillTargetIDs"]]
        effect_targets[effect["_id"]] = targets
        if any(_facility_matches(target, card, character)
               for target in targets for card, character in zip(cards, characters, strict=True)):
            required_ids.add(effect["_bandItemId"])
    missing = sorted(required_ids - facilities.keys())
    if missing:
        raise ValueError(f"Requires actual facility levels for IDs {missing}; no zero is assumed")
    rates = [ZERO for _ in cards]
    used = [[] for _ in cards]
    for identifier in sorted(required_ids):
        level = facilities[identifier]["level"]
        if level == 0:
            continue   # 未解锁：不加成
        effects = [row for row in tables["MasterBandItemSkillEffect"]
                   if row["_bandItemId"] == identifier and row["_level"] == level]
        if not effects:
            raise ValueError(f"No facility effects for ID {identifier} level {level}")
        for effect in effects:
            effect_rate = _effect_rates(effect)
            for index, (card, character) in enumerate(zip(cards, characters, strict=True)):
                matches = sum(_facility_matches(target, card, character)
                              for target in effect_targets[effect["_id"]])
                if matches:
                    rates[index] = tuple(_wrap32(rates[index][axis] + effect_rate[axis] * matches)
                                         for axis in range(3))
                    used[index].append(effect["_id"])
    return rates, used


def _parameter(tables: dict, key: str) -> int:
    row = _unique(tables["MasterParameter"], key, _id=key)
    if row["_type"] != "Int32":
        raise ValueError(f"Unsupported MasterParameter type for {key}")
    try:
        return _integer(int(row["_value"]), key)
    except (TypeError, ValueError) as error:
        raise ValueError(f"Invalid integer MasterParameter {key}") from error


def _total_rank_row(tables: dict, total_rank: int) -> dict:
    rows = tables["MasterCharacterTotalRank"]
    if not rows or total_rank > max(row["_totalRank"] for row in rows):
        raise ValueError("Character total rank is outside this snapshot's known range")
    eligible = [row for row in rows if row["_totalRank"] <= total_rank]
    if not eligible:
        raise ValueError("Character total rank has no source bonus row")
    return max(eligible, key=lambda row: row["_totalRank"])


def calculate_selected_deck_power(snapshot_dir: Path | str, profile: dict,
                                  member_ids: list[int], snap_ids: list[int],
                                  leader_member_id: int, song_id: int, event_id: int = 1,
                                  *, ordinary: bool = False) -> dict:
    """Calculate explicit member[i] / Snap[i] bindings in the selected live mode.

    This API accepts five distinct members / characters and five distinct Snaps.
    The leader is explicit, independent of list position. Leader formation
    conditions / cumulative effects and memories are outside
    this research implementation and raise errors if their data is requested.
    """
    if not isinstance(profile, dict):
        raise ValueError("profile must be an object")
    if not isinstance(member_ids, list) or not isinstance(snap_ids, list) or len(member_ids) != 5 or len(snap_ids) != 5:
        raise ValueError("A complete selection requires five members and five explicitly bound Snaps")
    leader_member_id = _integer(leader_member_id, "leader_member_id", minimum=1)
    song_id = _integer(song_id, "song_id", minimum=1)
    event_id = _integer(event_id, "event_id", minimum=1)
    if leader_member_id not in member_ids:
        raise ValueError("The explicit leader must be one of the selected members")
    snapshot_dir = Path(snapshot_dir)
    manifest, tables = _snapshot(snapshot_dir)
    for name in ("MasterMemoryMemberLevel", "MasterMemorySupportLevel", "MasterMemoryMusicBonus"):
        if tables[name]:
            raise ValueError(f"Nonempty {name} requires an unsupported memory model and actual player data")
    own = card_power.calculate_selected_card_power(snapshot_dir, profile, member_ids, snap_ids)
    bonuses = event_bonus.calculate_deck_bonuses(snapshot_dir, profile, member_ids, snap_ids, event_id)
    cards = [_unique(tables["MasterMemberCard"], "member card", _id=identifier) for identifier in member_ids]
    snaps = [_unique(tables["MasterSupportCard"], "Snap card", _id=identifier) for identifier in snap_ids]
    characters = [_unique(tables["MasterCharacter"], "character", _id=card["_characterID"]) for card in cards]
    if len({character["_id"] for character in characters}) != 5:
        raise ValueError("Five selected members must represent five distinct characters")
    for character in characters:
        _unique(tables["MasterBand"], "member band", _id=character["_bandID"])
    song = _unique(tables["MasterLiveMusic"], "song", _id=song_id)
    challenge = (None if ordinary else
                 _unique(tables["MasterChallengeMusic"], "challenge song for the event",
                         _eventId=event_id, _liveMusicId=song_id))
    music_type = challenge["_musicType"] if challenge and challenge["_musicType"] != 0 else song["_musicType"]
    rank_entries = _indexed_player_rows(profile, "character_ranks", "character_id")
    rank_rows = []
    for character in characters:
        identifier = character["_id"]
        if identifier not in rank_entries:
            raise ValueError(f"Requires actual character rank for ID {identifier}; no default is assumed")
        rank = _required(rank_entries[identifier], "rank", f"character {identifier}", minimum=1)
        rank_rows.append(_unique(tables["MasterCharacterRank"], "character rank", _rank=rank))
    total_rank = _required(profile, "character_total_rank", "profile", minimum=1)
    if total_rank < sum(row["_rank"] for row in rank_rows):
        raise ValueError("Character total rank cannot be below the selected characters' rank sum")
    total_rank_row = _total_rank_row(tables, total_rank)
    tgw_rank = _required(profile, "tgw_card_rank", "profile", minimum=1)
    tgw_rows = [row for row in tables["MasterVipRankBonus"] if row["_vipBonusType"] == 7]
    if not tgw_rows or tgw_rank > max(row["_vipRank"] for row in tgw_rows):
        raise ValueError("T.G.W rank is outside this snapshot's known power-bonus range")
    # Source master.rs explicitly has no type-7 grant at the actual initial rank 1.
    tgw_row = None if tgw_rank == 1 else _unique(tgw_rows, "T.G.W deck power bonus", _vipRank=tgw_rank)
    tgw_rate = 0 if tgw_row is None else tgw_row["_value"]
    leader_index = member_ids.index(leader_member_id)
    leader_rates, leader_rows = _leader_rates(tables, cards[leader_index],
                                            own["members"][leader_index]["leader_skill_level"], cards, characters)
    band_rates, band_rows = _band_rates(tables, profile, cards, characters)
    type_base = _parameter(tables, "music_type_base_bonus_rate")
    tag_base = _parameter(tables, "music_tag_base_bonus_rate")
    link_base = _parameter(tables, "type_link_base_bonus_rate")
    slots = []
    component_vectors = {name: ZERO for name in COMPONENT_NAMES}
    for index, (card, snap, character) in enumerate(zip(cards, snaps, characters, strict=True)):
        own_bp = _bp(own["members"][index]["parameters"])
        member_event_rate = 0 if ordinary else bonuses["members"][index]["parameter_bonus_10000"]
        snap_event_rate = 0 if ordinary else bonuses["snaps"][index]["parameter_bonus_10000"]
        base = _add(own_bp, _mul_floor(own_bp, (member_event_rate,) * 3))
        character_own = (rank_rows[index]["_bonus"] * UNIT,) * 3
        character_total = (total_rank_row["_bonus"] * UNIT,) * 3
        character_flat = _add(character_own, character_total)
        calculation_base = _add(base, character_flat)
        member_rank = _unique(tables["MasterMemberCardRank"], "member awakening bonuses",
                              _group=card["_memberCardRankGroup"], _rank=own["members"][index]["raw_rank"])
        support_rank = _unique(tables["MasterSupportCardRank"], "Snap link bonus",
                               _group=snap["_supportCardRankGroup"], _rank=own["snaps"][index]["raw_rank"])
        support_rate = tuple(own["snaps"][index]["support_rates_10000"][name] + snap_event_rate
                             for name in PARAMETERS)
        link_rate = link_base + support_rank["_cardTypeLinkBonusRate"] if card["_cardType"] == snap["_cardType"] else 0
        type_rate = type_base + member_rank["_musicTypeBonusRate"] if (
            card["_cardType"] == 99 or music_type == 99 or card["_cardType"] == music_type) else 0
        tag_rate = tag_base + member_rank["_musicTagBonusRate"] if (
            set(card["_bestMusicTagIDs"]) & set(song["_bestMusicTagIDs"])) else 0
        rates = {
            "support": support_rate, "band_items": band_rates[index], "leader_skill": leader_rates[index],
            "type_link": (link_rate,) * 3, "type_bonus": (type_rate,) * 3,
            "favored_music": (tag_rate,) * 3, "tgw_card": (tgw_rate,) * 3,
        }
        vectors = {"members": base, "character_rank": character_flat}
        for name in ("snaps", "band_items", "leader_skill", "type_link", "type_bonus", "favored_music", "tgw_card"):
            vectors[name] = _mul_floor(calculation_base, rates["support" if name == "snaps" else name])
        total = _add(*(vectors[name] for name in COMPONENT_NAMES))
        for name in COMPONENT_NAMES:
            component_vectors[name] = _add(component_vectors[name], vectors[name])
        slots.append({
            "slot_index": index, "member_id": card["_id"], "snap_id": snap["_id"],
            "character_id": character["_id"], "is_leader": index == leader_index,
            "own_parameters": own["members"][index]["parameters"],
            "base_parameters": _values(base, points=True),
            "character_rank_parameters": _values(character_own, points=True),
            "character_total_rank_parameters": _values(character_total, points=True),
            "calculation_base_parameters": _values(calculation_base, points=True),
            "components": {name: _values(vectors[name], points=True) for name in COMPONENT_NAMES},
            "total": _values(total, points=True),
            "rates_10000": {name: _values(value) for name, value in rates.items()},
            "event_parameter_rates_10000": {"member": member_event_rate, "snap": snap_event_rate},
            "source_row_ids": {
                "member_growth": own["members"][index]["source_row_ids"],
                "snap_growth": own["snaps"][index]["source_row_ids"],
                "character_rank": rank_rows[index]["_id"], "character_total_rank": total_rank_row["_id"],
                "leader_effects": leader_rows[index], "band_item_effects": band_rows[index],
                "member_event_effects": bonuses["members"][index]["matched_effect_row_ids"],
                "snap_event_effects": bonuses["snaps"][index]["matched_effect_row_ids"],
                "tgw_power_bonus": None if tgw_row is None else tgw_row["_id"],
            },
        })
    entries = {row["local_path"]: row for row in manifest["files"]}
    total = _add(*(component_vectors[name] for name in COMPONENT_NAMES))
    return {
        "scope": "Ordinary/challenge power; simple unconditional non-cumulative leader effects; no score simulation",
        "ordinary": ordinary,
        "event_id": event_id, "song_id": song_id, "leader_member_id": leader_member_id,
        "selected_member_ids": list(member_ids), "selected_snap_ids": list(snap_ids),
        "music_type": music_type, "slots": slots,
        "components": {name: _values(component_vectors[name], points=True) for name in COMPONENT_NAMES},
        "total": _values(total, points=True), "event_bonuses": bonuses,
        "source": {
            "data_commit": manifest["data_commit"], "model_commit": manifest["bdon_linked_model_commit"],
            "source_commit": manifest["source_commit"], "source_snapshot": manifest["source_snapshot"],
            "verified_file_count": len(REQUIRED_PATHS),
            "file_sha256": {relative: entries[relative]["sha256"] for relative in REQUIRED_PATHS},
            "song_row_id": song["_id"], "challenge_music_row_id": None if ordinary else challenge["_id"],
            "parameter_row_ids": ["music_type_base_bonus_rate", "music_tag_base_bonus_rate", "type_link_base_bonus_rate"],
        },
        "validation_scope": {
            "known_real_calibration": "One event-1 challenge team with screenshot-supplied development and player bonuses",
            "memory": "All three pinned MasterMemory tables are empty; no unobserved memory grant is inserted",
            "tgw_initial_rank": "An explicitly supplied rank 1 has no type-7 bonus row, following source master.rs",
            "unsupported": ["conditional or cumulative leader effects", "nonempty memory data", "score"],
        },
    }
