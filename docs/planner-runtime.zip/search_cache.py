"""Private, transactional sheet cache and resumable checkpoint (stdlib only)."""
from __future__ import annotations

import hashlib
from contextlib import contextmanager
import json
import os
from pathlib import Path
import sqlite3
import time

CACHE_SCHEMA = 1
MAX_CACHE_BYTES = 256 * 1024 * 1024


def digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
                                    separators=(",", ":"), allow_nan=False).encode("utf-8")).hexdigest()


def default_directory():
    override = os.environ.get("OURNOTES_PLANNER_STATE_DIR")
    if override:
        return Path(override).resolve()
    return Path(os.environ.get("LOCALAPPDATA", str(Path.home() / ".local/share"))) / "OurNotesPlanner"


class SearchCache:
    """Complete sheets and exact member-team cursors commit atomically.

    Files contain personal inputs; release builders must never include this dir.
    SQLite connections are short lived so HTTP and worker threads can share it.
    """
    def __init__(self, directory=None):
        self.directory = Path(directory) if directory is not None else default_directory()
        self.directory.mkdir(parents=True, exist_ok=True)
        self.path = self.directory / "search-v1.sqlite3"
        with self.connection() as db:
            db.execute("CREATE TABLE IF NOT EXISTS batches (key TEXT PRIMARY KEY, value TEXT NOT NULL, digest TEXT NOT NULL, bytes INTEGER NOT NULL, used REAL NOT NULL)")
            db.execute("CREATE TABLE IF NOT EXISTS checkpoint (id INTEGER PRIMARY KEY CHECK(id=1), value TEXT NOT NULL)")

    @contextmanager
    def connection(self):
        db = sqlite3.connect(self.path, timeout=15)
        try:
            with db:
                yield db
        finally:
            db.close()

    def get(self, key):
        with self.connection() as db:
            row = db.execute("SELECT value, digest FROM batches WHERE key=?", (key,)).fetchone()
            if row is None:
                return None
            try:
                value = json.loads(row[0])
                valid = digest(value) == row[1] and value["schema"] == CACHE_SCHEMA
                valid = valid and isinstance(value["rows"], list) and type(value["visited"]) is int
            except (ValueError, KeyError, TypeError):
                valid = False
            if not valid:
                db.execute("DELETE FROM batches WHERE key=?", (key,))
                return None
            db.execute("UPDATE batches SET used=? WHERE key=?", (time.time(), key))
            return value

    def put(self, key, rows, visited, **metadata):
        value = {"schema": CACHE_SCHEMA, "rows": rows, "visited": visited, **metadata}
        raw = json.dumps(value, ensure_ascii=False, separators=(",", ":"), allow_nan=False)
        size = len(raw.encode("utf-8"))
        if size > MAX_CACHE_BYTES:
            return False
        with self.connection() as db:
            db.execute("INSERT OR REPLACE INTO batches VALUES (?, ?, ?, ?, ?)",
                       (key, raw, digest(value), size, time.time()))
            total = db.execute("SELECT COALESCE(SUM(bytes),0) FROM batches").fetchone()[0]
            for old_key, old_size in db.execute("SELECT key, bytes FROM batches WHERE key<>? ORDER BY used", (key,)).fetchall():
                if total <= MAX_CACHE_BYTES:
                    break
                db.execute("DELETE FROM batches WHERE key=?", (old_key,))
                total -= old_size
        return True

    def get_partial(self, key):
        value = self.get("partial:" + key)
        if value is None or type(value.get("next_member")) is not int or value["next_member"] < 0:
            return None
        return value

    def put_partial(self, key, value):
        return self.put("partial:" + key, value["rows"], value["visited"],
                        next_member=value["next_member"], stats=value["stats"])

    def drop_partial(self, key):
        with self.connection() as db:
            db.execute("DELETE FROM batches WHERE key=?", ("partial:" + key,))

    def checkpoint(self, request, **metadata):
        value = {"request": request, "updated": time.time(), **metadata}
        raw = json.dumps(value, ensure_ascii=False, allow_nan=False)
        with self.connection() as db:
            db.execute("INSERT OR REPLACE INTO checkpoint VALUES (1, ?)", (raw,))

    def last_checkpoint(self):
        with self.connection() as db:
            row = db.execute("SELECT value FROM checkpoint WHERE id=1").fetchone()
        if row is None:
            return None
        try:
            result = json.loads(row[0])
            if not isinstance(result.get("request"), dict):
                return None
            # Eviction can remove old sheets. Report only currently available ones.
            result["saved_sheets"] = sum(self.get(key) is not None for key in result.get("keys", []))
            result["saved_steps"] = sum(self.get(key) is not None for key in result.get("step_keys", []))
            partial = self.get_partial(result["partial_key"]) if result.get("partial_key") else None
            result["saved_member_teams"] = partial["next_member"] if partial else 0
            return result
        except (ValueError, KeyError, TypeError):
            return None

    def mark_status(self, job_id, status):
        with self.connection() as db:
            row = db.execute("SELECT value FROM checkpoint WHERE id=1").fetchone()
            if row is None:
                return
            value = json.loads(row[0])
            if value.get("job_id") != job_id:
                return
            value.update(status=status, updated=time.time())
            db.execute("UPDATE checkpoint SET value=? WHERE id=1", (json.dumps(value, ensure_ascii=False),))
