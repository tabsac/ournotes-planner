@echo off
title OurNotes Account Package Extractor
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0get-account.ps1"
