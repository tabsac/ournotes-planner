@echo off
title Clean Phone USB Driver (Zadig / libwdi / libusbK)
fltmc >nul 2>&1
if %errorlevel% neq 0 (
    echo Requesting administrator rights...
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0clean-phone-driver.ps1"
