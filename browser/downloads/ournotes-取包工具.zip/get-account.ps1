﻿<#
  账号包一键提取工具 —— BanG Dream! Our Notes 配队助手
  双击「取包.bat」即可，不需要安装任何东西。
#>
param([string]$Serial = '', [switch]$NoOpen)

# adb 会把进度写到 stderr，用 Stop 会被当成致命错误，所以这里自己检查退出码
$ErrorActionPreference = 'Continue'
$Pkg    = 'com.bilibili.sirius.official'
$Remote = "/sdcard/Android/data/$Pkg/files"
$Adb    = Join-Path $PSScriptRoot 'adb.exe'
$OutDir = Join-Path $PSScriptRoot '账号包'
$Zip    = Join-Path $PSScriptRoot '账号包.zip'

function Line([string]$t = '') { Write-Host $t }
function Head([string]$t) { Write-Host ''; Write-Host "== $t ==" -ForegroundColor Cyan }
function Ok([string]$t)   { Write-Host "  [OK] $t" -ForegroundColor Green }
function Bad([string]$t)  { Write-Host "  [X]  $t" -ForegroundColor Red }
function Warn([string]$t) { Write-Host "  [!]  $t" -ForegroundColor Yellow }

function Show-DriverHelp {
  Head '连接不上手机？按顺序排查'
  Line '  1. 手机上：设置 → 关于手机 → 连点「版本号」7 次，打开开发者选项'
  Line '  2. 开发者选项里打开「USB 调试」，以及「『仅充电』模式下允许 ADB 调试」'
  Line '  3. 换一根「能传数据」的线（很多线只能充电），换一个 USB 口（优先主板后置）'
  Line '  4. 插上后手机会弹「是否允许 USB 调试」，勾选「始终允许」再点确定'
  Line '  5. 还不行就是电脑驱动问题：装一次「华为手机助手」或手机厂商的 PC 助手，'
  Line '     让它把驱动装好，再重新运行本工具'
  Line '  6. 如果之前用 Zadig 之类的工具改过这台手机的驱动，需要先在'
  Line '     「设备管理器」里右键该设备 → 卸载设备 → 勾选「删除驱动程序软件」，再重新插拔'
}

Line ''
Line '  BanG Dream! Our Notes —— 账号包一键提取' -ForegroundColor White
Line '  （本工具只读取游戏自己的存档文件，不上传任何内容）' -ForegroundColor DarkGray

# ---------- 1. adb ----------
Head '检查 adb'
if (-not (Test-Path $Adb)) {
  Bad "找不到 adb.exe（应该在 $PSScriptRoot）"
  Read-Host '按回车退出'
  exit 1
}
Ok "adb.exe 已就绪"

& $Adb start-server 2>&1 | Out-Null

# ---------- 2. 找设备 ----------
Head '查找手机（请保持数据线连接）'
$devices = @()
for ($i = 0; $i -lt 30; $i++) {
  $raw = & $Adb devices 2>$null
  $devices = @(
    $raw | Select-Object -Skip 1 | ForEach-Object {
      if ($_ -match '^(\S+)\s+(\S+)') {
        [pscustomobject]@{ Serial = $Matches[1]; State = $Matches[2] }
      }
    }
  )
  if ($devices | Where-Object { $_.State -eq 'device' }) { break }
  if ($i -eq 0) { Write-Host '  ...等待中' -NoNewline }
  else { Write-Host '.' -NoNewline }
  Start-Sleep -Seconds 1
}
Line ''

if ($Serial) {
  $pick = $devices | Where-Object { $_.Serial -eq $Serial -and $_.State -eq 'device' }
  if (-not $pick) { Bad "找不到设备 $Serial"; Show-DriverHelp; Read-Host '按回车退出'; exit 1 }
} else {
  $ready = @($devices | Where-Object { $_.State -eq 'device' })
  if ($ready.Count -eq 0) {
    $unauth = @($devices | Where-Object { $_.State -eq 'unauthorized' })
    if ($unauth.Count -gt 0) {
      Bad '手机已连上，但还没「授权」这台电脑'
      Line '  → 看手机屏幕，应该有一个「是否允许 USB 调试？」的弹窗，'
      Line '    勾选「始终允许」，点「允许」。然后重新运行本工具。'
      Line '  → 如果没看到弹窗：开发者选项 → 点「撤销 USB 调试授权」，再重新插拔数据线。'
    } else {
      Bad '没有检测到任何手机'
      Show-DriverHelp
    }
    Read-Host '按回车退出'
    exit 1
  }
  if ($ready.Count -gt 1) {
    Bad "检测到多台设备，请只插一台手机后重试："
    $ready | ForEach-Object { Line "     $($_.Serial)" }
    Read-Host '按回车退出'
    exit 1
  }
  $pick = $ready[0]
}
$serial = $pick.Serial
Ok "已连接：$serial"

# ---------- 3. 找存档目录 ----------
Head '定位游戏存档'
$listing = & $Adb -s $serial shell "ls $Remote" 2>&1
if ($LASTEXITCODE -ne 0 -or -not $listing) {
  Bad '读不到游戏的数据目录'
  Line '  → 请先在手机上「打开一次游戏并进入游戏」，再重新运行本工具。'
  Line '  → 如果确认进过游戏还是这样，说明手机系统限制较严，请把上面的报错发给我们。'
  Read-Host '按回车退出'
  exit 1
}
$hexDirs = @($listing | ForEach-Object { $_.Trim() } | Where-Object { $_ -match '^[0-9a-fA-F]{32,64}$' })
if ($hexDirs.Count -eq 0) {
  Bad '这台手机上没找到账号存档'
  Line '  → 请先在手机上「打开游戏、登录账号、进入游戏主界面」，然后重试。'
  Read-Host '按回车退出'
  exit 1
}
Ok "找到 $($hexDirs.Count) 个存档目录"

# ---------- 4. 下载 ----------
Head '下载存档（大约 3 MB）'
if (Test-Path $OutDir) { Remove-Item $OutDir -Recurse -Force }
New-Item -ItemType Directory -Path $OutDir -Force | Out-Null

$total = 0
$bytes = 0
foreach ($d in $hexDirs) {
  $dest = Join-Path $OutDir $d
  New-Item -ItemType Directory -Path $dest -Force | Out-Null

  # 逐个文件拉取，不要用 adb pull 整个目录：
  # adb 递归拉目录时会把非 ASCII 的目标路径搞坏（截断路径 → "Not a directory"）
  $rows  = & $Adb -s $serial shell "ls -l $Remote/$d" 2>$null
  $files = @()
  foreach ($r in $rows) {
    if ("$r" -match '^\S+\s+\d+\s+\S+\s+\S+\s+(\d+)\s+\S+\s+\S+\s+(\S+)\s*$') {
      $files += [pscustomobject]@{ Name = $Matches[2]; Size = [int64]$Matches[1] }
    }
  }
  if ($files.Count -eq 0) { Warn "存档目录 $d 里没有文件，跳过"; continue }

  foreach ($f in $files) {
    if ($f.Size -gt 16MB) { Warn "跳过过大的文件 $($f.Name)"; continue }
    & $Adb -s $serial pull "$Remote/$d/$($f.Name)" "$dest\$($f.Name)" 2>&1 | Out-Null
    if ($LASTEXITCODE -ne 0) { Bad "下载 $($f.Name) 失败"; Read-Host '按回车退出'; exit 1 }
    $total++
    $bytes += $f.Size
  }
}
if ($total -eq 0) { Bad '没有下载到任何文件'; Read-Host '按回车退出'; exit 1 }
Ok ('已下载 {0} 个文件（{1:N1} MB）' -f $total, ($bytes / 1MB))

# ---------- 5. 打包 ----------
Head '打包'
if (Test-Path $Zip) { Remove-Item $Zip -Force }
Compress-Archive -Path (Join-Path $OutDir '*') -DestinationPath $Zip -Force
$kb = [math]::Round((Get-Item $Zip).Length / 1KB, 0)
Ok "账号包.zip  ($kb KB)"

Head '完成！接下来'
Line '  1. 浏览器打开配队助手网页'
Line '  2. 切到「账号包导入」标签'
Line '  3. 把刚生成的「账号包.zip」直接拖进网页（或点「选择文件」选中它）'

Line ''
Line "  文件位置：$Zip" -ForegroundColor White
if (-not $NoOpen) { Start-Process explorer.exe "/select,`"$Zip`"" }
Line ''
Read-Host '按回车退出'
