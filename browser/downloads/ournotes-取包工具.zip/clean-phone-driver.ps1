﻿# 清理 Zadig / libwdi / libusbK 给安卓手机装上的驱动
# 目的：把被 WinUSB/libusbK 抢走的复合设备还给 Windows，让 ADB 接口重新出现
# 需要管理员权限（配套的 .bat 会自动提权）
# 加 -DryRun 只显示会删什么、不真删，用来先看一眼

param([switch]$DryRun)

$ErrorActionPreference = 'Continue'

function Line([string]$t = '') { Write-Host $t }
function Ok([string]$t)   { Write-Host "  [OK] $t" -ForegroundColor Green }
function Bad([string]$t)  { Write-Host "  [X]  $t" -ForegroundColor Red }
function Warn([string]$t) { Write-Host "  [!]  $t" -ForegroundColor Yellow }

Line ''
Line '  清理手机上被 Zadig 类工具替换掉的 USB 驱动' -ForegroundColor White
Line ''

# ---------- 0. 必须是管理员 ----------
$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
           ).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin -and -not $DryRun) {
  Bad '没有管理员权限。请右键「以管理员身份运行」配套的 .bat。'
  Read-Host '按回车退出'
  exit 1
}
if ($DryRun) { Warn '预演模式（-DryRun）：只看会删什么，不会真的删' }
else { Ok '管理员权限正常' }

# ---------- 1. 确认手机已拔掉 ----------
$present = @(Get-PnpDevice -PresentOnly -ErrorAction SilentlyContinue |
             Where-Object { $_.InstanceId -like '*VID_12D1*' })
if ($present.Count -gt 0) {
  Warn '检测到手机还插着，请先拔掉数据线再运行（占用中的驱动删不掉）。'
  $present | ForEach-Object { Line "        $($_.FriendlyName)  $($_.InstanceId)" }
  Read-Host '拔掉后按回车继续'
}

# ---------- 2. 枚举驱动包 ----------
# 千万不要去解析 pnputil 输出里的标签文字！
#   「已发布的名称 / Published Name」这类标签会随系统语言和代码页变化，
#   提权控制台的代码页和普通控制台不同，中文标签会被解码成乱码，
#   于是「已发布的名称」和「Published Name」两边都匹配不上 —— 上一版就栽在这里，
#   表现为扫描结果永远是「没有发现」。
# 所以只用两种不含文字的结构化来源：
#   A) Get-WindowsDriver（DISM，结构化字段，最可靠）
#   B) pnputil 的「行位置」结构：oemXX.inf 的下一行就是原始名称
Line ''
Line '== 扫描驱动包 =='

# 基础：pnputil 的「行位置」结构（永远可用，不认任何标签文字）
$all   = @()
$lines = @((pnputil /enum-drivers) -split "`r?`n")
for ($i = 0; $i -lt $lines.Count; $i++) {
  if ($lines[$i] -match '(oem\d+\.inf)') {
    $inf  = $Matches[1]
    $nxt  = if ($i + 1 -lt $lines.Count) { $lines[$i + 1] } else { '' }
    $orig = (($nxt -split '\s+') | Where-Object { $_ } | Select-Object -Last 1)
    if ($orig -match '^oem\d+\.inf$') { $orig = '' }   # 下一行又是发布名，说明没有原始名
    $all += [pscustomobject]@{ Inf = $inf; Orig = [string]$orig; Prov = '' }
  }
}

# 增强：如果 DISM 可用，用它补上 provider 信息（只用来显示，不参与判定）
$howBy = 'pnputil(结构化)'
try {
  $rows = @(Get-WindowsDriver -Online -ErrorAction Stop)
  $map  = @{}
  foreach ($r in $rows) { $d = [string]$r.Driver; if ($d) { $map[$d] = [string]$r.ProviderName } }
  if ($map.Count -gt 0) {
    foreach ($d in $all) { if ($map.ContainsKey($d.Inf)) { $d.Prov = $map[$d.Inf] } }
    $howBy = 'pnputil(结构化) + Get-WindowsDriver'
  }
} catch { }
if ($all.Count -eq 0) {
  Bad '连驱动列表都没读到 —— 请把下面的报错发给我们。'
  try { Get-WindowsDriver -Online -ErrorAction Stop | Out-Null } catch { Line "     $($_.Exception.Message)" }
  (pnputil /enum-drivers) | Select-Object -First 8 | ForEach-Object { Line "     $_" }
  Read-Host '按回车退出'
  exit 1
}
Ok "读到 $($all.Count) 个驱动包（来源：$howBy）"

# ---------- 3. 只挑属于这台手机的 ----------
# 两类目标：
#   (a) 原始 INF 名里含 hbn-al80 —— Zadig 给这台手机专门生成的，无条件清
#   (b) libusbK 的【通用】INF（drv_device / drv_accessory*）—— 它们匹配 USB\COMPOSITE
#       这种超宽兼容 ID，会在 (a) 被删掉后立刻把手机抢走。但这类 INF 也可能被别的设备用，
#       所以必须先确认「用它设备全都是 VID_12D1 手机」才删。
# 判定完全不依赖界面语言（只看结构字段）。
$usersByInf = @{}
Get-CimInstance Win32_PnPSignedDriver -ErrorAction SilentlyContinue | ForEach-Object {
  $k = [string]$_.InfName
  if (-not $k) { return }
  if (-not $usersByInf.ContainsKey($k)) { $usersByInf[$k] = New-Object System.Collections.ArrayList }
  [void]$usersByInf[$k].Add([string]$_.DeviceID)
}

function Test-OnlyPhoneUses([string]$inf) {
  if (-not $usersByInf.ContainsKey($inf)) { return $true }   # 没设备在用，删了安全
  foreach ($dev in $usersByInf[$inf]) { if ($dev -notmatch 'VID_12D1') { return $false } }
  return $true
}

$targets = @($all | Where-Object {
  if ($_.Orig -match 'hbn-al80') { return $true }                       # (a) 无条件
  if ($_.Orig -match '^(drv_accessory|drv_accessory_adb|drv_device)\.inf$') {
    return (Test-OnlyPhoneUses $_.Inf)                                  # (b) 需确认没别的设备在用
  }
  return $false
})
$others  = @($all | Where-Object { $targets.Inf -notcontains $_.Inf -and ($_.Orig -match 'usb_receiver|ipad|drv_accessory|drv_device' -or $_.Prov -match 'libwdi|libusbK') })

if ($targets.Count -eq 0) {
  Ok '没有发现属于这台手机的异常驱动包 —— 已经清理干净了。'
  if ($others.Count -gt 0) {
    Line ''
    Line '  （库里还有这些 libwdi/libusbK 驱动，但不属于手机，不要删）：' -ForegroundColor DarkGray
    $others | Select-Object -First 8 | ForEach-Object {
      Write-Host ("    {0,-12} {1}" -f $_.Inf, $_.Orig) -ForegroundColor DarkGray
    }
  }
} else {
  Line '  将被删除（已确认属于这台手机，且没有别的设备在用）：'
  $targets | ForEach-Object { Line ("    {0,-12} {1,-42} [{2}]" -f $_.Inf, $_.Orig, $_.Prov) }
  Line ''
  $failed = 0
  foreach ($t in $targets) {
    Write-Host "  删除 $($t.Inf) ... " -NoNewline
    if ($DryRun) { Write-Host '（预演，未删除）' -ForegroundColor Yellow; continue }
    $r = (pnputil /delete-driver $t.Inf /uninstall /force) 2>&1 | Out-String
    if ($LASTEXITCODE -eq 0) { Write-Host '成功' -ForegroundColor Green }
    else {
      Write-Host '失败' -ForegroundColor Red
      $failed++
      Line ("     " + ($r.Trim() -replace "`r?`n", ' '))
    }
  }
  if ($failed -gt 0) {
    Line ''
    Warn "有 $failed 个没删掉。常见原因：还有设备的隐藏节点占着它。"
    Line '  → 设备管理器 → 查看 → 显示隐藏的设备 → 把灰色的手机节点删掉 → 再跑一次本脚本。'
  }
}

# ---------- 4. 删掉残留的设备节点 ----------
Line ''
Line '== 清理残留设备节点 =='
$ghosts = @(Get-PnpDevice -ErrorAction SilentlyContinue |
            Where-Object { $_.InstanceId -like '*VID_12D1*' })
if ($ghosts.Count -eq 0) {
  Ok '没有残留节点'
} else {
  foreach ($g in $ghosts) {
    Write-Host "  移除 $($g.FriendlyName) / $($g.InstanceId) ... " -NoNewline
    if ($DryRun) { Write-Host '（预演，未移除）' -ForegroundColor Yellow; continue }
    (pnputil /remove-device "$($g.InstanceId)") 2>&1 | Out-Null
    if ($LASTEXITCODE -eq 0) { Write-Host '成功' -ForegroundColor Green }
    else { Write-Host '跳过（多半是隐藏节点，去设备管理器删）' -ForegroundColor Yellow }
  }
}

# ---------- 5. 复查 ----------
Line ''
Line '== 复查 =='
$left  = @()
$lines = @((pnputil /enum-drivers) -split "`r?`n")
for ($i = 0; $i -lt $lines.Count; $i++) {
  if ($lines[$i] -match '(oem\d+\.inf)') {
    $nxt = if ($i + 1 -lt $lines.Count) { $lines[$i + 1] } else { '' }
    if ($nxt -match 'hbn-al80') { $left += $Matches[1] }
  }
}
if ($DryRun) {
  if ($targets.Count -gt 0) { Warn "预演未删，所以还在：$(($targets | ForEach-Object { $_.Inf }) -join ', ')" }
} elseif ($left.Count -gt 0) {
  Bad ('还残留：' + ($left -join ', '))
} else {
  Ok '属于手机的异常驱动已清理干净'
}

Line ''
Line '  接下来：' -ForegroundColor White
Line '    1. 重新插上手机'
Line '    2. 手机上开发者选项打开「USB 调试」和「『仅充电』模式下允许 ADB 调试」'
Line '    3. 手机弹出「是否允许 USB 调试」→ 勾选「始终允许」→ 允许'
Line '    4. 双击工具里的「取包.bat」'
Line ''
Read-Host '按回车退出'
